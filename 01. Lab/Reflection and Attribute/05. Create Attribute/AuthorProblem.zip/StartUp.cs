﻿using System;

namespace AuthorProblem
{
    [Author("John")]
    class StartUp
    {
        [Author("James")]
        static void Main()
        {

        }
    }
}
